References
CSV Reader
https://www.npmjs.com/package/react-csv-reader

React Data table
https://www.npmjs.com/package/react-data-table-component