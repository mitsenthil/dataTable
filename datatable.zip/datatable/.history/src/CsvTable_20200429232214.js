import React from 'react';
import DataTable from 'react-data-table-component';
import CSVReader from "react-csv-reader";
 
const papaparseOptions = {
  header: true,
  dynamicTyping: true,
  skipEmptyLines: true,
  transformHeader: header => header.toLowerCase().replace(/\W/g, "_")
};

const columns = [
  {
    name: 'policyID',
    selector: 'policyid',
    sortable: true,
  },
  {
    name: 'statecode',
    selector: 'statecode',
    sortable: true
  },
];
 
class CsvTable extends React.Component {
  state = {
    columns: [],
    json_data: []
  }

  constructColumns = (data) =>{
      let columns = [];
      if(data) {
      Object.keys(data[0]).forEach(key => {
        let columnItem = {};
        columnItem.name = key;
        columnItem.selector = key.toLowerCase();
        columnItem.sortable = true;
        columns.push(columnItem);
      })
      }
  }
  
  handleForce = (data, fileInfo) => {
    debugger;
    this.constructColumns(data);
    this.setState({json_data: data})
  };
  

  render() {
    return (
      <div>

      <CSVReader
      cssClass="react-csv-input"
      label="Select CSV"
      onFileLoaded={this.handleForce}
      parserOptions={papaparseOptions}
    />
      <DataTable
        columns={this.state.columns}
        data={this.state.json_data}
      />
      </div>
    )
  }
};

export default CsvTable;