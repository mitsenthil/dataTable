import React from 'react';
import logo from './logo.svg';
import './App.css';
import CsvTable from './CsvTable';

function App() {
  return (
    <div className="App">
      <CsvTable/>
    </div>
  );
}

export default App;
