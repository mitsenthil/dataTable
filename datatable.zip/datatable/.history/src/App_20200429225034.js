import React from 'react';
import logo from './logo.svg';
import './App.css';
import CsvTable from './CsvTable';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      </header>
      <CsvTable/>
    </div>
  );
}

export default App;
