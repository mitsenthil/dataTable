import React from 'react';
import DataTable from 'react-data-table-component';
import CSVReader from "react-csv-reader";
 
const papaparseOptions = {
  header: true,
  dynamicTyping: true,
  skipEmptyLines: true,
  transformHeader: header => header.toLowerCase().replace(/\W/g, "_")
};

let json_data =[];

const handleForce = function(data, fileInfo){
  json_data = data;
}

const columns = [
  {
    name: 'policyID',
    selector: 'policyID',
    sortable: true,
  },
  {
    name: 'statecode',
    selector: 'statecode',
    sortable: true,
    right: true,
  },
];
 
class CsvTable extends React.Component {
  render() {
    return (
      <div>
      <CSVReader
      cssClass="react-csv-input"
      label="Select CSV"
      onFileLoaded={handleForce}
      parserOptions={papaparseOptions}
    />
      <DataTable
        title="Arnold Movies"
        columns={columns}
        data={json_data}
      />
      </div>
    )
  }
};

export default CsvTable;