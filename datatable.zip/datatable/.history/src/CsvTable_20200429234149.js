import React from "react";
import DataTable from "react-data-table-component";
import CSVReader from "react-csv-reader";

const papaparseOptions = {
  header: true,
  dynamicTyping: true,
  skipEmptyLines: true,
  transformHeader: (header) => header.toLowerCase().replace(/\W/g, "_"),
};

class CsvTable extends React.Component {
  state = {
    columns: [],
    json_data: [],
  };

  constructColumns = (data) => {
    let columns_data = [];
    if (data) {
      Object.keys(data[0]).forEach((key) => {
        let columnItem = {};
        columnItem.name = key;
        columnItem.selector = key.toLowerCase();
        columnItem.sortable = true;
        columns_data.push(columnItem);
      });
    }
    return columns_data;
  };

  handleFileUpload = (data, fileInfo) => {
    debugger;
    let columns_data = this.constructColumns(data);
    this.setState({ json_data: data, columns: columns_data });
  };

  render() {
    return (
      <div>
        <div class="reader">
          <CSVReader
            cssClass="react-csv-input"
            label="Select CSV"
            onFileLoaded={this.handleFileUpload}
            parserOptions={papaparseOptions}
          />
        </div>
        <DataTable
          columns={this.state.columns}
          data={this.state.json_data}
          fixedHeader
        />
      </div>
    );
  }
}

export default CsvTable;
